import { Heading } from '@chakra-ui/react'
import React from 'react'

const Homepage = () => {
  return (
    <div>
      <Heading>hii homepage</Heading>
      
    </div>
  )
}

export default Homepage
